
    <!-- Footer Section -->
    <div class="container-fluid text-center p-3">
        <a href="#">
            <img src="https://img.icons8.com/fluency/48/000000/facebook-new.png" /> </a>
        <a href="#">
            <img src="https://img.icons8.com/fluency/48/000000/instagram-new.png" /> </a>
        <a href="#">
            <img src="https://img.icons8.com/cotton/64/000000/twitter.png" />
        </a>
        <br><br>
        <p class="text-white fs-6">
            All right reserved. Designed By
            <br>
            <a href="#" class="text-white text-decoration-none">
                Let's Learn Programming
            </a>
        </p>
    </div>
    <!-- Footer Section -->
    <!-- End Coding Here -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa"
        crossorigin="anonymous"></script>
</body>

</html>
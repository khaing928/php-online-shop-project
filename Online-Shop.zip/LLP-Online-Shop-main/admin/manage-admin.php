<?php include("widget/header.php"); ?>

    <div class="container">
        <div class="row pt-4 pb-4 gt-3">
            <h2 class="mt-4 mb-3">Manage Admin</h2>
            <?php 
                if(isset($_SESSION['noti'])) {
                    echo $_SESSION['noti'];
                    unset($_SESSION['noti']);
                }
            ?>
               
            <!-- Admin Table -->
            <div class="col-12">
                <a href="add-admin.php" class="btn btn-primary w-10 mb-3">Add Admin</a>
                <table class="table table-light table-striped">
                <thead>
                  <tr>
                      <th scope="col">#</th>
                      <th scope="col">Full Name</th>
                      <th scope="col">User Name</th>
                      <th scope="col">Action</th>
                      </tr>
                </thead>

                <!-- Retrieve Data from Database -->
                <?php
                    $sql = "SELECT * FROM admins";
                    $res = mysqli_query($conn,$sql);

                    if($res){
                        $count = mysqli_num_rows($res);

                        if($count == 0) {
                            echo 'no data';
                        }else {
                            $sn = 1;
                            while($row = mysqli_fetch_assoc($res)) {
                                
                                $id = $row['id'];
                                $fullname = $row['fullname'];
                                $username = $row['username'];
                                $password = $row['password'];

                                ?>
                                <!-- Can Now code HTML -->
                                <tr>
                                    <th scope="row"><?= $sn ?></th>
                                        <td><?= $fullname ?></td>
                                        <td><?= $username ?></td>
                                        <td>
                                            <a href="<?= SITEURL ?>admin/update-password.php?id=<?= $id ?>" class="bg-white p-2 rounded mx-1" title="update password">
                                                <img src="../images/icons8-forgot-password-48.png" width ="20px"
                                                alt="">
                                            </a>
                                            <a href="<?= SITEURL ?>admin/update-admin.php?id=<?= $id ?>" class="bg-white p-2 rounded mx-1" title="update admin">
                                                <img src="../images/icons8-edit-64.png" width ="20px"
                                                alt="">
                                            </a>
                                            <a href="<?= SITEURL ?>admin/delete-admin.php?id=<?= $id ?>" class="bg-white p-2 rounded mx-1" title="delete admin">
                                                <img src="../images/icons8-delete-30.png" width ="20px"
                                                alt="">
                                            </a>
                                        </td>
                                </tr>
                                <?php
                                $sn++;
                            }
                        }
                    }
                ?>
                    
                </table>
                
                
                    </div>
        </div>
    </div>

<?php include("widget/footer.php"); ?>
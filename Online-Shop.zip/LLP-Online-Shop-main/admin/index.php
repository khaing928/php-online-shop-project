<?php include("widget/header.php"); ?>

    <!-- Dashboard Section -->
    <div class="container p-3">
        <br><br>
        <?php
                        if(isset($_SESSION['noti'])) {
                            echo $_SESSION['noti'];
                            unset($_SESSION['noti']);
                        }
                    ?>
        <h2 class="text-black text-float opacity-75">Dashboard</h2>
        <br><br>
        <div class="row">
            <div class="col-md-3 p-2">
                <a href="category-product.html" class="text-decoration-none text-dark">
                    <div class="pb-3 border-0 rounded-4 bg-body shadow p-3">
                        
                        <div class="card-body py-3">
                            <?php
                                    $sql = "SELECT * FROM categories";
                                    $res = mysqli_query($conn,$sql);

                                    $count = mysqli_num_rows($res);

                                ?>
                            <h4>
                                <?= $count ?>
                            </h4>
                            <h5 class="card-title">
                                Categories
                            </h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 p-2">
                <a href="category-product.html" class="text-decoration-none text-dark">
                    <div class="pb-3 border-0 rounded-4 bg-body shadow p-3">
                        
                        <div class="card-body py-3">
                        <?php
                                    $sql = "SELECT * FROM products";
                                    $res = mysqli_query($conn,$sql);

                                    $count = mysqli_num_rows($res);

                                ?>
                            <h4><?= $count ?></h4>    
                            <h5 class="card-title">
                                Product
                            </h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 p-2">
                <a href="category-product.html" class="text-decoration-none text-dark">
                    <div class="pb-3 border-0 rounded-4 bg-body shadow p-3">
                        
                        <div class="card-body py-3">
                            <?php
                                    $sql = "SELECT * FROM Orders";
                                    $res = mysqli_query($conn,$sql);

                                    $count = mysqli_num_rows($res);

                                ?>
                                <h4><?= $count ?></h4>
                            <h5 class="card-title">
                                Total Orders
                            </h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 p-2">
                <a href="category-product.html" class="text-decoration-none text-dark">
                    <div class="pb-3 border-0 rounded-4 bg-body shadow p-3">
                        
                        <div class="card-body py-3">
                            <?php
                                    $sql = "SELECT * FROM orders WHERE status = 'Delivered'";
                                    $res = mysqli_query($conn,$sql);

                                    $total = 0;
                                    while($row = mysqli_fetch_assoc($res)){
                                        $total += $row['total'];
                                    }

                                ?>
                            <h4>$ <?= $total ?></h4>
                            <h5 class="card-title">
                                Revenue Generated
                            </h5>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        
    </div>
    <!-- Promotion Section -->

<?php include("widget/footer.php"); ?>


<?php
session_start(); // use for session
ob_start(); // use for page navigation

define('SITEURL','http://localhost/LLP-Online-Shop-main/');

$server_name = "localhost";
$username ="root";
$password = "";
$dbname = "project";

$conn = mysqli_connect($server_name,$username,$password,$dbname);

if($conn) {
    // echo "Connected";
}else {
    die("error on the connection" .mysqli_error());
};